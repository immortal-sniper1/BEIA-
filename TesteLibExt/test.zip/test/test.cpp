#include <test.h> 



namespace testtt
{
    double beia::Add(double a, double b)
    {
        return a + b;
    }

    double beia::Subtract(double a, double b)
    {
        return a - b;
    }

    double beia::Multiply(double a, double b)
    {
        return a * b;
    }

    double beia::Divide(double a, double b)
    {
        return a / b;
    }
}
